// ═══════════════════════════════════════════════════════════════
// 타이어핑 최저가 봇 - sidebar.js
// ═══════════════════════════════════════════════════════════════

const BASE = "https://www.tireping.com";

// ── 전역 상태 ────────────────────────────────────────────────
let allProducts   = [];
let shownProducts = [];
let filterState   = {};   // {colName: Set(값)}
let sortCol       = null;
let sortRev       = false;
let checkedSet    = new Set();  // iid(인덱스) 집합
let autoRefreshing = false;
let companyMap    = {};   // {name: id}
let patternMap    = {};   // {name: id}
let myStoreId     = "";
let lastShiftIdx  = null;

// ── 컬럼 정의 ────────────────────────────────────────────────
const COLS = [
  { key: "chk",          label: "✔",      w: 22,  sort: null },
  { key: "판매",         label: "판매",   w: 36,  sort: "is_mine" },
  { key: "제조사",       label: "제조사", w: 50,  sort: "manufacturer" },
  { key: "제품명",       label: "제품명", w: 120, sort: "product", left: true },
  { key: "사이즈",       label: "사이즈", w: 72,  sort: "size" },
  { key: "세부정보",     label: "세부정보",w: 90, sort: null, left: true },
  { key: "DOT",          label: "DOT",    w: 38,  sort: "dot" },
  { key: "공장도가",     label: "공장도", w: 68,  sort: "factory_price" },
  { key: "시장최저가",   label: "시장최저",w: 68, sort: "market_lowest" },
  { key: "시장재고",     label: "시장재고",w:44,  sort: "market_stock" },
  { key: "내판매가",     label: "내가격", w: 68,  sort: "my_price" },
  { key: "DC율",         label: "DC%",    w: 40,  sort: "dc_rate" },
  { key: "경쟁최저가",   label: "경쟁최저",w: 68, sort: "lowest_price" },
  { key: "2등가격",      label: "2등",    w: 68,  sort: "second_price" },
  { key: "차이",         label: "차이",   w: 54,  sort: "diff" },
  { key: "판매재고",     label: "판매재고",w:44,  sort: "my_stock" },
  { key: "상태",         label: "상태",   w: 62,  sort: "status_order" },
  { key: "액션",         label: "",       w: 90,  sort: null },
];

// ── 유틸 ─────────────────────────────────────────────────────
function toInt(s) {
  const m = String(s).replace(/,/g, "").match(/\d+/g);
  return m ? parseInt(m.join("")) : 0;
}
function toFloat(s) {
  const m = String(s).match(/[\d.]+/);
  return m ? parseFloat(m[0]) : 0;
}
function calcDc(factory, price) {
  if (!factory || !price) return 0;
  return Math.round((factory - price) / factory * 1000) / 10;
}
function comma(n) {
  return n ? Number(n).toLocaleString() : "-";
}
function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

// ── DOM 헬퍼 ─────────────────────────────────────────────────
const $  = id => document.getElementById(id);
const st = msg => { $("status-bar").textContent = msg; };
const loading = (show, msg = "처리 중...") => {
  $("loading").classList.toggle("show", show);
  $("loading-msg").textContent = msg;
};

// ── Fetch (background 경유) ───────────────────────────────────
function bgFetch(url, options = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type: "FETCH", url, options }, res => {
      if (chrome.runtime.lastError) return reject(chrome.runtime.lastError);
      if (!res) return reject(new Error("응답 없음"));
      resolve(res);
    });
  });
}

// HTML 파서
function parseHTML(text) {
  const dp = new DOMParser();
  return dp.parseFromString(text, "text/html");
}

// ── 로그인 체크 ───────────────────────────────────────────────
async function checkLogin() {
  try {
    const r = await bgFetch(`${BASE}/sell/index`);
    const doc = parseHTML(r.text);
    const el = doc.querySelector(".h-info div p");
    if (el) {
      myStoreId = el.textContent.trim();
      $("login-status").textContent = myStoreId;
      return true;
    }
    $("login-status").textContent = "로그인 필요";
    return false;
  } catch(e) {
    $("login-status").textContent = "오류";
    return false;
  }
}

// ── 제조사 목록 ───────────────────────────────────────────────
async function loadCompanies() {
  const r = await bgFetch(`${BASE}/buy/insert`);
  const doc = parseHTML(r.text);
  const sel = doc.querySelector("select[name='company']");
  companyMap = {};
  if (sel) {
    for (const opt of sel.querySelectorAll("option")) {
      const v = opt.value.trim();
      const n = opt.textContent.trim();
      if (n) companyMap[n] = v;
    }
  }
  const mfrSel = $("sel-mfr");
  mfrSel.innerHTML = '<option value="">제조사</option>';
  Object.keys(companyMap).sort().forEach(n => {
    const o = document.createElement("option");
    o.value = companyMap[n]; o.textContent = n;
    mfrSel.appendChild(o);
  });
}

async function loadPatterns(companyId) {
  patternMap = {};
  const prodSel = $("sel-prod");
  prodSel.innerHTML = '<option value="">제품명</option>';
  if (!companyId) return;
  try {
    const r = await bgFetch(`${BASE}/ajax/tire/pattern/${companyId}`);
    const data = JSON.parse(r.text);
    for (const p of data) {
      if (p.name && p.id) {
        patternMap[p.name.trim()] = String(p.id);
        const o = document.createElement("option");
        o.value = p.id; o.textContent = p.name;
        prodSel.appendChild(o);
      }
    }
  } catch(e) {}
}

// ── 캐시 (chrome.storage.local) ──────────────────────────────
async function loadCache() {
  return new Promise(resolve => {
    chrome.storage.local.get("tireping_cache", r => {
      resolve(r.tireping_cache || {});
    });
  });
}

async function saveCache(cache) {
  return new Promise(resolve => {
    chrome.storage.local.set({ tireping_cache: cache }, resolve);
  });
}

async function updateCache(products) {
  const cache = await loadCache();
  let added = 0;
  for (const p of products) {
    if (p.tire_id && !cache[p.tire_id]) {
      cache[p.tire_id] = {
        tire_id: p.tire_id, manufacturer: p.manufacturer,
        product: p.product, size: p.size, detail: p.detail,
        dot: p.dot, factory_price: p.factory_price,
        market_lowest: p.market_lowest, market_stock: p.market_stock || 0,
      };
      added++;
    }
  }
  await saveCache(cache);
  return added;
}

function fromCache(cache, { search = "", mfr = "", prod = "", dot = "" } = {}) {
  const s = search.replace(/[\s/rR]/g, "");
  return Object.values(cache)
    .filter(c => {
      if (s && !c.size.replace(/[\s/rR]/g, "").includes(s)) return false;
      if (mfr && !c.manufacturer.toLowerCase().includes(mfr.toLowerCase())) return false;
      if (prod && prod !== "0" && !c.product.toLowerCase().includes(prod.toLowerCase())) return false;
      if (dot && dot !== "DOT" && c.dot !== dot) return false;
      return true;
    })
    .map(c => ({
      tire_id: c.tire_id, manufacturer: c.manufacturer,
      product: c.product, size: c.size, detail: c.detail || "",
      dot: c.dot, factory_price: c.factory_price,
      market_lowest: c.market_lowest || 0, market_stock: c.market_stock || 0,
      pid: null, my_price: 0, my_stock: 0, dc_rate: 0,
      is_mine: false, lowest_price: 0, second_price: 0,
    }));
}

// ── /buy/insert 파싱 ──────────────────────────────────────────
async function fetchBuyInsert({ search = "", company = "", pattern = "",
  dot = "DOT", order = "" } = {}, statusCb) {
  const products = [];
  let page = 1;
  while (true) {
    if (statusCb) statusCb(`⏳ 구매목록 ${page}페이지 수집 중...`);
    const params = new URLSearchParams({
      search, company, pattern, code: "",
      width: "단면폭", height: "편평비", inch: "인치",
      dot, order, page,
    });
    const r = await bgFetch(`${BASE}/buy/insert?${params}`);
    const doc = parseHTML(r.text);
    const rows = doc.querySelectorAll("table.table-list tbody tr");
    if (!rows.length) break;

    for (const row of rows) {
      const onclick = row.getAttribute("onclick") || "";
      const m = onclick.match(/\/buy\/insert\/view\/(\d+)\?dot=([^']+)/);
      if (!m) continue;
      const tire_id = m[1], tire_dot_raw = m[2];

      const tds = row.querySelectorAll("td");
      if (tds.length < 3) continue;

      const manufacturer = tds[0]?.textContent.trim() || "";
      const product      = row.querySelector(".t-name")?.textContent.trim() || "";
      const size         = tds[2]?.textContent.trim().replace(/\s+/g, " ") || "";
      const detail       = tds[3]?.textContent.trim().replace(/\s+/g, " ") || "";

      let row_dot = tire_dot_raw;
      for (const td of row.querySelectorAll("td.eng")) {
        if (/^\d{4}$/.test(td.textContent.trim())) { row_dot = td.textContent.trim(); break; }
      }

      const fp_el   = row.querySelector("td.hide-mobile span.eng");
      const low_el  = row.querySelector("td.text-green b.price, td.text-green b.eng");
      const stk_el  = row.querySelector("td.text-purple b.eng");

      products.push({
        tire_id, manufacturer, product, size,
        detail: detail.slice(0, 40), dot: row_dot,
        factory_price: fp_el  ? toInt(fp_el.textContent)  : 0,
        market_lowest: low_el ? toInt(low_el.textContent) : 0,
        market_stock:  stk_el ? toInt(stk_el.textContent) : 0,
        pid: null, my_price: 0, my_stock: 0, dc_rate: 0,
        is_mine: false, lowest_price: 0, second_price: 0,
      });
    }

    // 다음 페이지 확인
    const paging = doc.querySelector(".page-paging");
    if (!paging) break;
    const hasNext = paging.querySelector(`a[href*="page=${page + 1}"]`) ||
                    paging.querySelector("a i.fa-angle-double-right");
    if (!hasNext) break;
    page++;
    await sleep(150);
  }
  return products;
}

// ── 내 판매상품 수집 ──────────────────────────────────────────
// search: 사이즈 공백제거(2454518), company: 제조사ID, pattern: 품명ID, dot: DOT년도
async function fetchMyProducts(statusCb, { search="", company="0", pattern="0", dot="0" } = {}) {
  const allRows = [];
  let page = 1;
  while (true) {
    if (statusCb) statusCb(`⏳ 내 판매상품 ${page}페이지...`);
    const url = `${BASE}/sell/price?page=${page}&company=${company}&pattern=${pattern}&width=0&height=0&inch=0&dot=${dot}&code=&search=${search}&order=`;
    const r   = await bgFetch(url);
    const doc = parseHTML(r.text);
    const rows = doc.querySelectorAll("table.table-list tbody tr");
    if (!rows.length) break;
    const firstText = rows[0].textContent;
    if (firstText.includes("등록된 상품이 없습니다")) break;

    for (const row of rows) {
      const btn = row.querySelector("button[data-id]");
      if (!btn) continue;
      const pid = btn.getAttribute("data-id")?.trim();
      if (!pid) continue;
      allRows.push({
        pid,
        factory_price: toInt(row.querySelector(".mfactoryprice")?.textContent || "0"),
        dc_rate:       toFloat(row.querySelector("input.msdc")?.value || "0"),
        my_price:      toInt(row.querySelector("input.msprice")?.value || "0"),
        my_stock:      toInt(row.querySelector("input.mcount")?.value || "0"),
      });
    }
    const paging = doc.querySelector(".page-paging");
    if (!paging) break;
    const hasNext = paging.querySelector(`a[href*="page=${page + 1}"]`) ||
                    paging.querySelector("a i.fa-angle-double-right");
    if (!hasNext) break;
    page++;
  }
  if (!allRows.length) return {};

  // pid → tire_id 매핑 (캐시 사용)
  const tireCache = await loadTireCache();
  const newRows   = allRows.filter(r => !tireCache[r.pid]);

  if (newRows.length) {
    if (statusCb) statusCb(`⏳ 상품 매칭 중 (0/${newRows.length})...`);
    let done = 0;
    // 순차 처리 (병렬 8개씩)
    for (let i = 0; i < newRows.length; i += 8) {
      const batch = newRows.slice(i, i + 8);
      await Promise.all(batch.map(async item => {
        try {
          const r   = await bgFetch(`${BASE}/sell/price/update/${item.pid}`);
          const doc = parseHTML(r.text);
          const inp = doc.querySelector("input[name='tire']");
          if (inp?.value) tireCache[item.pid] = inp.value.trim();
        } catch(e) {}
        done++;
        if (statusCb && done % 5 === 0)
          statusCb(`⏳ 상품 매칭 중 (${done}/${newRows.length})...`);
      }));
    }
    await saveTireCache(tireCache);
  }

  const my = {};
  for (const item of allRows) {
    const tid = tireCache[item.pid];
    if (!tid) continue;
    // 중복 tire_id 는 재고수량(my_stock) 높은 것 우선 유지
    if (!my[tid] || item.my_stock > my[tid].my_stock) {
      my[tid] = item;
    }
  }
  return my;
}

async function loadTireCache() {
  return new Promise(r => chrome.storage.local.get("tire_cache", d => r(d.tire_cache || {})));
}
async function saveTireCache(c) {
  return new Promise(r => chrome.storage.local.set({ tire_cache: c }, r));
}

// ── 내 상품 매칭 ─────────────────────────────────────────────
function matchMy(products, myMap) {
  for (const p of products) {
    const info = myMap[p.tire_id];
    if (info) {
      p.pid          = info.pid;
      p.my_price     = info.my_price;
      p.my_stock     = info.my_stock;
      p.dc_rate      = info.dc_rate;
      p.factory_price= info.factory_price || p.factory_price;
      p.is_mine      = true;
    }
  }
}

// ── 경쟁사 최저가 조회 ────────────────────────────────────────
async function fetchOneLowest(p) {
  try {
    const r   = await bgFetch(`${BASE}/buy/insert/view/${p.tire_id}?dot=${p.dot}`);
    const doc = parseHTML(r.text);
    const prices = [], allPrices = [];
    let myExcluded = false;

    for (const row of doc.querySelectorAll("table tbody tr")) {
      const pel = row.querySelector("td b.eng");
      if (!pel) continue;
      const v = toInt(pel.textContent);
      if (v <= 1000) continue;
      allPrices.push(v);

      let isMine = false;
      const green = row.querySelector("p.bg-green, p.text-green");
      if (green && green.textContent.includes("내 판매상품")) isMine = true;
      if (!isMine && myStoreId && row.textContent.includes(myStoreId)) isMine = true;
      if (!isMine && !myExcluded && v === p.my_price) { myExcluded = true; isMine = true; }
      if (!isMine) prices.push(v);
    }

    const mlow = allPrices.length ? Math.min(...allPrices) : 0;
    if (!prices.length) return [0, 0, mlow];
    const u = [...new Set(prices)].sort((a,b) => a - b);
    return [u[0], u[1] ?? u[0], mlow];
  } catch(e) {
    return [0, 0, 0];
  }
}

async function fetchLowestAll(products, statusCb) {
  const mine = products.filter(p => p.is_mine);
  let done = 0;
  for (let i = 0; i < mine.length; i += 8) {
    const batch = mine.slice(i, i + 8);
    await Promise.all(batch.map(async p => {
      const [low, sec, mlow] = await fetchOneLowest(p);
      p.lowest_price  = low;
      p.second_price  = sec;
      p.market_lowest = mlow;
      done++;
      if (statusCb) statusCb(`🔎 경쟁사 최저가 [${done}/${mine.length}]`);
    }));
  }
}

// ── 가격 저장 ─────────────────────────────────────────────────
async function savePrice(pid, price, stock) {
  const params = new URLSearchParams({
    pid, sprice: String(price), dprice: "", pcount: String(stock)
  });
  const r = await bgFetch(`${BASE}/ajax/price/setcount?${params}`, { method: "POST" });
  try {
    const data = JSON.parse(r.text);
    if (data.code === "ok") return { ok: true };
    return { ok: false, msg: data.msg };
  } catch(e) {
    return { ok: false, msg: r.text };
  }
}

// ── 검색 ─────────────────────────────────────────────────────
async function doSearch(useCache) {
  loading(true, "검색 중...");
  filterState = {};
  checkedSet.clear();

  const search  = $("inp-size").value.trim();
  const company = $("sel-mfr").value;
  const pattern = $("sel-prod").value;
  const dot     = $("sel-dot").value || "DOT";
  const order   = $("sel-order").value;
  const mfrName = $("sel-mfr").options[$("sel-mfr").selectedIndex]?.text || "";
  const prodName= $("sel-prod").options[$("sel-prod").selectedIndex]?.text || "";

  try {
    let products = [];

    if (useCache) {
      const cache = await loadCache();
      products = fromCache(cache, {
        search, mfr: mfrName === "제조사" ? "" : mfrName,
        prod: prodName === "제품명" ? "" : prodName,
        dot: dot === "DOT" ? "" : dot,
      });
      st(`📦 캐시 ${products.length}개 로드 — 새 상품 확인 중...`);
    }

    // 새로 수집
    const fresh = await fetchBuyInsert({ search, company, pattern, dot, order }, st);
    await updateCache(fresh);

    if (useCache) {
      // 캐시에 없는 새 상품 추가
      const existIds = new Set(products.map(p => p.tire_id));
      for (const p of fresh) {
        if (!existIds.has(p.tire_id)) products.push(p);
      }
    } else {
      products = fresh;
    }

    if (!products.length) { st("⚠️ 검색 결과 없음"); loading(false); return; }

    st(`✅ ${products.length}개 — 내 판매상품 수집 중...`);
    // sell/price 에도 동일 필터 적용 → 해당 상품만 수집해서 매칭 속도 대폭 단축
    const sellSearch  = search.replace(/\s/g, "");          // "245 45 18" → "2454518"
    const sellCompany = company || "0";
    const sellPattern = pattern || "0";
    const sellDot     = (dot && dot !== "DOT") ? dot : "0";
    const myMap = await fetchMyProducts(st, {
      search:  sellSearch,
      company: sellCompany,
      pattern: sellPattern,
      dot:     sellDot,
    });
    matchMy(products, myMap);

    const mineN = products.filter(p => p.is_mine).length;
    st(`✅ ${mineN}개 매칭 — 경쟁사 최저가 조회 중...`);
    await fetchLowestAll(products, st);

    // 파생값 사전 계산 (정렬/필터가 즉시 작동하도록)
    products.forEach(calcDerivedFields);
    allProducts   = products;
    shownProducts = [...products];
    renderTable(shownProducts);
    st(`✅ 완료! 전체 ${products.length}개 | 내 판매 ${mineN}개`);
  } catch(e) {
    st(`❌ 오류: ${e.message}`);
    console.error(e);
  } finally {
    loading(false);
  }
}

// ── 테이블 렌더링 ─────────────────────────────────────────────
function calcRow(p, idx) {
  // 파생값 최신화 (refreshRow 포함 모든 경로에서 정확한 값 보장)
  calcDerivedFields(p);
  const my  = p.my_price, low = p.lowest_price, sec = p.second_price;
  let tag = "notmine", status = p._status || "⬜ 미판매", statusOrder = p._statusOrder ?? 3;
  let diff = "-", lowBtn = "", raiseBtn = "", uploadBtn = "";

  if (p.is_mine && low > 0) {
    const isLow = my <= low;
    tag         = isLow ? "mine-green" : "mine-red";
    status      = isLow ? "✅ 최저가" : "❌ 비최저가";
    statusOrder = isLow ? 1 : 0;
    diff        = my > low ? `-${my - low}` : "0";
    lowBtn      = !isLow
      ? `<button class="btn-red btn-low" data-idx="${idx}">⬇최저가</button>` : "";
    raiseBtn    = isLow && sec > my
      ? `<button class="btn-green btn-raise" data-idx="${idx}">⬆${comma(sec-10)}</button>` : "";
  } else if (p.is_mine) {
    tag = "mine-only"; status = "단독판매"; statusOrder = 2;
  } else {
    uploadBtn = `<button class="btn-purple btn-upload" data-idx="${idx}">📤등록</button>`;
  }

  p._status      = status;
  p._statusOrder = statusOrder;
  p._diff        = diff;

  const chk = checkedSet.has(idx) ? "☑" : "☐";

  return `<tr class="${tag}" data-idx="${idx}">
    <td class="chk-cell" data-idx="${idx}">${chk}</td>
    <td>${p.is_mine ? "🔵" : "⬜"}</td>
    <td>${p.manufacturer}</td>
    <td class="td-left" title="${p.product}">${p.product}</td>
    <td>${p.size}</td>
    <td class="td-left" title="${p.detail || ''}">${p.detail ? p.detail.slice(0,18) : "-"}</td>
    <td>${p.dot}</td>
    <td>${p.factory_price ? comma(p.factory_price)+"원" : "-"}</td>
    <td>${p.market_lowest ? comma(p.market_lowest)+"원" : "-"}</td>
    <td>${p.market_stock || "-"}</td>
    <td>${my ? comma(my)+"원" : "-"}</td>
    <td>${(() => {
      if (p.is_mine && p.dc_rate) return p.dc_rate + "%";
      if (!p.is_mine && p.factory_price && p.market_lowest)
        return calcDc(p.factory_price, p.market_lowest) + "%";
      return "-";
    })()}</td>
    <td>${low ? comma(low)+"원" : "-"}</td>
    <td>${sec ? comma(sec)+"원" : "-"}</td>
    <td>${diff}</td>
    <td>${p.is_mine ? (p.my_stock || "-") : "-"}</td>
    <td>${status}</td>
    <td class="btn-cell">${lowBtn}${raiseBtn}${uploadBtn}</td>
  </tr>`;
}

// tire_id → shownProducts 인덱스 맵 (refreshRow 빠른 조회용)
let tireIdxMap = {};

function renderTable(products) {
  shownProducts = products;
  checkedSet = new Set([...checkedSet].filter(i => i < products.length));
  // tire_id → idx 맵 갱신
  tireIdxMap = {};
  products.forEach((p, i) => { if (p.tire_id) tireIdxMap[p.tire_id] = i; });

  // 헤더 렌더
  const thead = $("thead");
  thead.innerHTML = `<tr>${COLS.map(c => {
    const canSort = c.sort !== null;
    const sortCls = sortCol === c.key ? (sortRev ? "sort-desc" : "sort-asc") : "";
    return `<th style="width:${c.w}px;min-width:${c.w}px;cursor:${canSort?"pointer":"default"}"
      class="${sortCls}" data-col="${c.key}">${c.label}</th>`;
  }).join("")}</tr>`;

  // onclick 직접 세팅 (이벤트 위임/버블링 문제 완전 우회)
  const FILTERABLE = ["판매","제조사","제품명","사이즈","세부정보","DOT","상태","DC율","차이"];
  Array.from(thead.querySelectorAll("th")).forEach((th, i) => {
    const c = COLS[i];
    if (!c) return;
    if (c.sort !== null) {
      th.onclick = () => doSort(c.key);
    }
    if (FILTERABLE.includes(c.key)) {
      th.oncontextmenu = e => { e.preventDefault(); showFilterPopup(c.key, th); };
    }
  });

  // 바디 렌더
  $("tbody").innerHTML = products.map((p, i) => calcRow(p, i)).join("");

  updateSummary(products);
  updateFilterLabel();
}

function refreshRow(idx) {
  const p = shownProducts[idx];
  if (!p) return;
  const tr = $("tbody").querySelector(`tr[data-idx="${idx}"]`);
  if (!tr) return;
  const tmp = document.createElement("tbody");
  tmp.innerHTML = calcRow(p, idx);
  tr.replaceWith(tmp.firstElementChild);
}

// tire_id 로 해당 행 즉시 갱신 (정렬/필터 후에도 정확)
function refreshRowByTireId(tireId) {
  const idx = tireIdxMap[tireId];
  if (idx === undefined) return;
  refreshRow(idx);
}

function updateSummary(products) {
  const total  = products.length;
  const mine   = products.filter(p => p.is_mine).length;
  const red    = products.filter(p => p.is_mine && p.lowest_price > 0 && p.my_price > p.lowest_price).length;
  const noComp = products.filter(p => p.is_mine && p.lowest_price === 0).length;
  $("summary-text").textContent =
    `총 ${total}개 | 🔵내판매 ${mine}개 | ⬜미판매 ${total-mine}개 | 🔴비최저가 ${red}개 | 🟢최저가 ${mine-red-noComp}개 | 단독 ${noComp}개`;
}

function updateFilterLabel() {
  const keys = Object.keys(filterState);
  if (keys.length) {
    $("filter-status").textContent = "🔽 " + keys.map(k => `${k}(${filterState[k].size})`).join(" / ");
    $("btn-clear-filter").style.display = "";
  } else {
    $("filter-status").textContent = "";
    $("btn-clear-filter").style.display = "none";
  }
}

// ── 필터 ─────────────────────────────────────────────────────
function getFilterVal(p, col) {
  switch(col) {
    case "판매":     return p.is_mine ? "🔵 판매중" : "⬜ 미판매";
    case "제조사":   return p.manufacturer || "";
    case "제품명":   return p.product || "";
    case "사이즈":   return p.size || "";
    case "세부정보": return p.detail ? p.detail.slice(0, 18) : "";
    case "DOT":      return p.dot || "";
    case "상태":     return p._status || (p.is_mine
                       ? (p.lowest_price > 0
                           ? (p.my_price <= p.lowest_price ? "✅ 최저가" : "❌ 비최저가")
                           : "단독판매")
                       : "⬜ 미판매");
    case "DC율": {
      const dc = p.is_mine && p.dc_rate
        ? p.dc_rate
        : (p.factory_price && p.market_lowest
            ? calcDc(p.factory_price, p.market_lowest) : 0);
      if (!dc) return "-";
      if (dc >= 60) return "60%이상";
      if (dc >= 50) return "50~59%";
      if (dc >= 40) return "40~49%";
      if (dc >= 30) return "30~39%";
      if (dc >= 20) return "20~29%";
      return "20%미만";
    }
    case "차이": {
      // 미판매 or 단독판매는 해당없음
      if (!p.is_mine || p.lowest_price === 0) return "해당없음";
      const diff = p.my_price - p.lowest_price;
      if (diff === 0) return "±0 (최저가)";
      if (diff <= 0)  return "최저가";  // 내가 더 쌈
      // 비최저가 구간
      if (diff <= 10)   return "▲10원이하";
      if (diff <= 50)   return "▲11~50원";
      if (diff <= 100)  return "▲51~100원";
      if (diff <= 300)  return "▲101~300원";
      if (diff <= 1000) return "▲301~1000원";
      return "▲1000원초과";
    }
    default: return "";
  }
}

// 액션바 우클릭 시 필터할 컬럼 선택 팝업
function showColumnFilterPicker(x, y) {
  document.querySelector(".filter-picker")?.remove();
  const filterable = ["판매","제조사","제품명","사이즈","세부정보","DOT","상태","DC율","차이"];
  const picker = document.createElement("div");
  picker.className = "filter-popup filter-picker";
  picker.style.cssText = `position:fixed;left:${x}px;top:${y}px;z-index:9999;`;
  picker.innerHTML = `<div class="fp-title">📋 필터 적용할 컬럼 선택</div>
    ${filterable.map(col => {
      const active = filterState[col] ? " style='font-weight:bold;color:#2563eb'" : "";
      return `<label${active} data-col="${col}" style="cursor:pointer;padding:3px 6px;display:block;border-radius:3px;"
        onmouseover="this.style.background='#f0f4ff'" onmouseout="this.style.background=''">${col}${filterState[col] ? " 🔽" : ""}</label>`;
    }).join("")}`;

  picker.querySelectorAll("label[data-col]").forEach(lbl => {
    lbl.addEventListener("click", e => {
      e.stopPropagation();
      const col = lbl.dataset.col;
      picker.remove();
      // 해당 컬럼 헤더 th 를 찾아서 filterPopup 표시
      const th = document.querySelector(`#thead th[data-col="${col}"]`);
      if (th) showFilterPopup(col, th);
      else {
        // th 가 없으면 화면 중앙에 팝업
        const fakeEl = { getBoundingClientRect: () => ({ bottom: y, left: x }) };
        showFilterPopup(col, fakeEl);
      }
    });
  });

  document.body.appendChild(picker);
  setTimeout(() => document.addEventListener("click", () => picker.remove(), { once: true }), 50);
}

function showFilterPopup(colKey, thEl) {
  // 기존 팝업 모두 제거
  document.querySelectorAll(".filter-popup").forEach(el => el.remove());

  // 필터 값 수집: allProducts 없으면 shownProducts 사용
  const source = allProducts.length ? allProducts : shownProducts;
  const vals = [...new Set(source.map(p => getFilterVal(p, colKey)))]
    .filter(Boolean).sort((a, b) => a.localeCompare(b, "ko"));
  if (!vals.length) { alert(`[${colKey}] 필터할 값이 없습니다`); return; }

  // 현재 필터 상태 — filterState[colKey]는 Set이므로 안전하게 변환
  const curSet = filterState[colKey] instanceof Set
    ? filterState[colKey]
    : new Set(vals);  // 필터 없으면 전체 선택 상태

  const popup = document.createElement("div");
  popup.className = "filter-popup";

  // 팝업 위치: th 기준, 화면 밖으로 나가지 않게 보정
  let top = 0, left = 0;
  if (thEl && typeof thEl.getBoundingClientRect === "function") {
    const rect = thEl.getBoundingClientRect();
    top  = rect.bottom + window.scrollY;
    left = rect.left   + window.scrollX;
  }
  popup.style.cssText = `position:fixed;top:${top}px;left:${left}px;z-index:9999;`;

  // 체크박스 목록 생성
  const itemsHtml = vals.map(v => {
    const checked = curSet.has(v) ? "checked" : "";
    return `<label class="fp-item"><input type="checkbox" value="${v}" ${checked}><span>${v}</span></label>`;
  }).join("");

  popup.innerHTML = `
    <div class="fp-title">🔽 ${colKey} 필터</div>
    <div class="fp-items">${itemsHtml}</div>
    <div class="fp-btns">
      <button class="btn-gray fp-all">전체선택</button>
      <button class="btn-gray fp-none">전체해제</button>
      <button class="btn-blue fp-apply">✅ 적용</button>
      <button class="btn-gray fp-clear">초기화</button>
    </div>`;

  const allInputs = () => popup.querySelectorAll("input[type=checkbox]");
  popup.querySelector(".fp-all").onclick  = () => allInputs().forEach(i => i.checked = true);
  popup.querySelector(".fp-none").onclick = () => allInputs().forEach(i => i.checked = false);

  popup.querySelector(".fp-apply").onclick = () => {
    const selected = [...allInputs()].filter(i => i.checked).map(i => i.value);
    if (selected.length === vals.length || selected.length === 0) {
      delete filterState[colKey];
    } else {
      filterState[colKey] = new Set(selected);
    }
    popup.remove();
    applyFilters();
    updateFilterLabel();
  };

  popup.querySelector(".fp-clear").onclick = () => {
    delete filterState[colKey];
    popup.remove();
    applyFilters();
    updateFilterLabel();
  };

  document.body.appendChild(popup);

  // 화면 밖 보정
  const pr = popup.getBoundingClientRect();
  if (pr.right > window.innerWidth)
    popup.style.left = Math.max(0, window.innerWidth - pr.width - 8) + "px";
  if (pr.bottom > window.innerHeight)
    popup.style.top  = Math.max(0, top - pr.height - 4) + "px";

  // 팝업 외부 클릭 시 닫기
  const outsideClick = e => {
    if (!popup.contains(e.target)) { popup.remove(); document.removeEventListener("click", outsideClick); }
  };
  setTimeout(() => document.addEventListener("click", outsideClick), 80);
}

function applyFilters() {
  if (!Object.keys(filterState).length) {
    renderTable([...allProducts]);
    updateFilterLabel();
    return;
  }
  const filtered = allProducts.filter(p =>
    Object.entries(filterState).every(([col, allowed]) => {
      // Set 타입 보장
      const s = allowed instanceof Set ? allowed : new Set(allowed);
      return s.has(getFilterVal(p, col));
    })
  );
  renderTable(filtered);
  updateFilterLabel();
}

// ── 파생값 사전 계산 (정렬/필터 전에 항상 호출) ─────────────
// p._statusOrder, p._diff_val 을 미리 세팅해두어야 정렬이 정확함
function calcDerivedFields(p) {
  const my  = p.my_price   || 0;
  const low = p.lowest_price || 0;
  const sec = p.second_price || 0;

  if (p.is_mine && low > 0) {
    const isLow      = my <= low;
    p._statusOrder   = isLow ? 1 : 0;
    p._status        = isLow ? "✅ 최저가" : "❌ 비최저가";
    p._diff_val      = my - low;   // 양수=비최저가, 0=동률, 음수=내가더쌈
  } else if (p.is_mine) {
    p._statusOrder   = 2;
    p._status        = "단독판매";
    p._diff_val      = null;       // 해당없음
  } else {
    p._statusOrder   = 3;
    p._status        = "⬜ 미판매";
    p._diff_val      = null;
  }
}

// ── 정렬 ─────────────────────────────────────────────────────
function getSortVal(p, sortKey) {
  switch(sortKey) {
    case "is_mine":      return p.is_mine ? 0 : 1;          // 판매중 먼저
    case "manufacturer": return p.manufacturer || "";
    case "product":      return p.product || "";
    case "size":         return p.size || "";
    case "dot":          return p.dot || "";
    case "factory_price":return p.factory_price || 0;
    case "market_lowest":return p.market_lowest || 0;
    case "market_stock": return p.market_stock || 0;
    case "my_price":     return p.my_price || 0;
    case "dc_rate":      return p.is_mine
                           ? (p.dc_rate || 0)
                           : (p.factory_price && p.market_lowest
                               ? calcDc(p.factory_price, p.market_lowest) : 0);
    case "lowest_price": return p.lowest_price || 0;
    case "second_price": return p.second_price || 0;
    case "diff":
      // 실제 정렬은 doSort의 커스텀 comparator가 담당
      return p._diff_val ?? 999999;
    case "my_stock":     return p.my_stock || 0;
    case "status_order": return p._statusOrder ?? 9;
    default:             return 0;
  }
}

function doSort(colKey) {
  const col = COLS.find(c => c.key === colKey);
  if (!col || col.sort === null) return;
  sortRev = sortCol === colKey ? !sortRev : false;
  sortCol = colKey;

  const sorted = [...shownProducts].sort((a, b) => {
    // 차이 컬럼 전용
    if (col.sort === "diff") {
      const getDiff = p => {
        if (!p.is_mine || p.lowest_price === 0) return null;
        return p.my_price - p.lowest_price;
      };
      const da = getDiff(a), db = getDiff(b);
      // 비최저가(양수)만 위로, 나머지(0/null)는 항상 맨 아래
      const aUp = da !== null && da > 0;
      const bUp = db !== null && db > 0;
      if (aUp && bUp) return sortRev ? db - da : da - db;
      if (aUp) return -1;
      if (bUp) return  1;
      return 0;
    }

    // 일반 컬럼
    const av = getSortVal(a, col.sort);
    const bv = getSortVal(b, col.sort);
    if (typeof av === "string") {
      const cmp = av.localeCompare(bv, "ko");
      return sortRev ? -cmp : cmp;
    }
    return sortRev ? bv - av : av - bv;
  });

  renderTable(sorted);
}

// ── 체크박스 ─────────────────────────────────────────────────
function toggleCheck(idx) {
  if (checkedSet.has(idx)) checkedSet.delete(idx);
  else checkedSet.add(idx);
  const td = $("tbody").querySelector(`td.chk-cell[data-idx="${idx}"]`);
  if (td) td.textContent = checkedSet.has(idx) ? "☑" : "☐";
  lastShiftIdx = idx;
}

function checkAll()     { shownProducts.forEach((_,i) => checkedSet.add(i));    rerenderChecks(); }
function uncheckAll()   { checkedSet.clear();                                    rerenderChecks(); }
function checkNotLow()  {
  checkedSet.clear();
  shownProducts.forEach((p,i) => {
    if (p.is_mine && p.lowest_price > 0 && p.my_price > p.lowest_price) checkedSet.add(i);
  });
  rerenderChecks();
}
function checkNotMine() {
  checkedSet.clear();
  shownProducts.forEach((p,i) => { if (!p.is_mine) checkedSet.add(i); });
  rerenderChecks();
}
function rerenderChecks() {
  $("tbody").querySelectorAll("td.chk-cell").forEach(td => {
    td.textContent = checkedSet.has(Number(td.dataset.idx)) ? "☑" : "☐";
  });
}

// ── 가격 변경 ─────────────────────────────────────────────────
async function changePrice(p, idx, target) {
  st(`⏳ ${p.product} ${p.size} 변경 중...`);
  const res = await savePrice(p.pid, target, p.my_stock);
  if (res.ok) {
    p.my_price  = target;
    p.dc_rate   = calcDc(p.factory_price, target);
    const [low, sec, mlow] = await fetchOneLowest(p);
    p.lowest_price = low; p.second_price = sec; p.market_lowest = mlow;
    refreshRowByTireId(p.tire_id);  // tire_id 기반으로 정확한 행 갱신
    st(`✅ ${p.product} ${p.size} → ${comma(target)}원`);
  } else {
    st(`❌ 저장 실패: ${res.msg}`);
  }
}

// ── 일괄 가격 변경 ────────────────────────────────────────────
async function bulkLow() {
  const targets = [...checkedSet].map(i => ({ p: shownProducts[i], i }))
    .filter(({p}) => p?.is_mine && p.lowest_price > 0 && p.my_price > p.lowest_price);
  if (!targets.length) { alert("최저가 적용 가능한 항목 없음"); return; }
  if (!confirm(`${targets.length}개를 최저가-10원으로 변경할까요?`)) return;
  loading(true, `0/${targets.length} 변경 중...`);
  for (let k = 0; k < targets.length; k++) {
    const {p, i} = targets[k];
    $("loading-msg").textContent = `${k+1}/${targets.length} 변경 중...`;
    const target = p.lowest_price - 10;
    const res = await savePrice(p.pid, target, p.my_stock);
    if (res.ok) {
      p.my_price = target; p.dc_rate = calcDc(p.factory_price, target);
      const [low,sec,mlow] = await fetchOneLowest(p);
      p.lowest_price = low; p.second_price = sec; p.market_lowest = mlow;
      refreshRowByTireId(p.tire_id);
    }
    await sleep(300);
  }
  loading(false);
  st(`✅ ${targets.length}개 최저가 적용 완료`);
}

async function bulkRaise() {
  const targets = [...checkedSet].map(i => ({ p: shownProducts[i], i }))
    .filter(({p}) => p?.is_mine && p.lowest_price > 0 &&
      p.my_price <= p.lowest_price && p.second_price > p.my_price);
  if (!targets.length) { alert("2등+10원 올리기 가능한 항목 없음"); return; }
  if (!confirm(`${targets.length}개를 2등가격-10원으로 변경할까요?`)) return;
  loading(true, `0/${targets.length} 변경 중...`);
  for (let k = 0; k < targets.length; k++) {
    const {p, i} = targets[k];
    $("loading-msg").textContent = `${k+1}/${targets.length} 변경 중...`;
    const target = p.second_price - 10;
    const res = await savePrice(p.pid, target, p.my_stock);
    if (res.ok) {
      p.my_price = target; p.dc_rate = calcDc(p.factory_price, target);
      const [low,sec,mlow] = await fetchOneLowest(p);
      p.lowest_price = low; p.second_price = sec; p.market_lowest = mlow;
      refreshRowByTireId(p.tire_id);
    }
    await sleep(300);
  }
  loading(false);
  st(`✅ ${targets.length}개 2등+10원 완료`);
}

// ── 최저가 새로고침 (내 판매가/재고 + 경쟁가 동시 갱신) ────────
async function refreshLowest() {
  if (!allProducts.length) { st("⚠️ 먼저 검색해주세요"); return; }
  $("btn-refresh-now").disabled = true;

  // ── 1단계: 내 판매상품 재조회 (가격/재고 변동 감지) ─────────
  // 현재 검색 필터 그대로 재사용해서 빠르게 수집
  st("🔃 내 판매상품 재조회 중...");
  try {
    const search  = $("inp-size").value.trim();
    const company = $("sel-mfr").value || "0";
    const pattern = $("sel-prod").value || "0";
    const dot     = $("sel-dot").value;
    const myMap   = await fetchMyProducts(null, {
      search:  search.replace(/\s/g, ""),
      company, pattern,
      dot: (dot && dot !== "DOT") ? dot : "0",
    });

    let myChanged = 0;
    for (const p of allProducts) {
      const info = myMap[p.tire_id];
      if (p.is_mine && info) {
        if (info.my_price !== p.my_price || info.my_stock !== p.my_stock) {
          p.my_price = info.my_price;
          p.my_stock = info.my_stock;
          p.dc_rate  = info.dc_rate;
          myChanged++;
          refreshRowByTireId(p.tire_id);
        }
      } else if (!p.is_mine && info) {
        // 새로 내 판매상품이 된 경우
        p.pid = info.pid; p.my_price = info.my_price;
        p.my_stock = info.my_stock; p.dc_rate = info.dc_rate;
        p.factory_price = info.factory_price || p.factory_price;
        p.is_mine = true;
        myChanged++;
        refreshRowByTireId(p.tire_id);
      }
    }
    if (myChanged > 0) st(`🔃 내 판매상품 ${myChanged}개 변동 감지`);
  } catch(e) {
    console.warn("내 판매상품 재조회 실패:", e);
  }

  // ── 2단계: 경쟁사 최저가 재조회 ────────────────────────────
  const mine = allProducts.filter(p => p.is_mine);
  if (!mine.length) {
    $("btn-refresh-now").disabled = false;
    st("⚠️ 내 판매 상품 없음");
    return;
  }

  let done = 0;
  for (let i = 0; i < mine.length; i += 8) {
    const batch = mine.slice(i, i + 8);
    await Promise.all(batch.map(async p => {
      const [low, sec, mlow] = await fetchOneLowest(p);
      const changed = low !== p.lowest_price || sec !== p.second_price || mlow !== p.market_lowest;
      p.lowest_price = low; p.second_price = sec; p.market_lowest = mlow;
      done++;
      st(`🔃 경쟁가 새로고침 [${done}/${mine.length}]`);
      if (changed) refreshRowByTireId(p.tire_id);
    }));
  }

  $("btn-refresh-now").disabled = false;
  updateSummary(shownProducts);
  st(`✅ 새로고침 완료 (${new Date().toLocaleTimeString()}) — ${mine.length}개`);
}

// ── 자동갱신 ─────────────────────────────────────────────────
let autoIntervalTimer = null;

async function toggleAuto() {
  if (autoRefreshing) {
    autoRefreshing = false;
    if (autoIntervalTimer) { clearInterval(autoIntervalTimer); autoIntervalTimer = null; }
    $("btn-auto").textContent = "▶ 자동갱신";
    $("btn-auto").className   = "btn-sky";
    $("auto-status").textContent = "";
    st("자동갱신 중지");
  } else {
    if (!allProducts.length) { alert("먼저 검색해주세요"); return; }
    autoRefreshing = true;
    $("btn-auto").textContent = "⏹ 갱신중지";
    $("btn-auto").className   = "btn-red";
    const mins = parseInt($("sel-interval").value);
    let remaining = mins * 60;
    const tick = () => {
      remaining--;
      const m = Math.floor(remaining / 60), s = remaining % 60;
      $("auto-status").textContent = `⏱ ${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`;
      if (remaining <= 0) {
        remaining = mins * 60;
        refreshLowest();
      }
    };
    autoIntervalTimer = setInterval(tick, 1000);
    st(`자동갱신 시작 (${mins}분 간격)`);
  }
}

// ── 상품 업로드 (등록) ────────────────────────────────────────
function buildInsertJS(p, maxDc, stock) {
  let sellPrice = p.lowest_price > 0 ? p.lowest_price - 10
    : p.market_lowest > 0 ? p.market_lowest - 10 : 0;

  if (maxDc !== null && p.factory_price > 0 && sellPrice > 0) {
    const dcOfBase = (p.factory_price - sellPrice) / p.factory_price * 100;
    if (dcOfBase > maxDc) {
      sellPrice = Math.floor(p.factory_price * (1 - maxDc / 100) / 10) * 10;
    }
  }

  const mfr     = p.manufacturer.replace(/'/g, "\\'");
  const product = p.product.replace(/'/g, "\\'");
  const tire_id = p.tire_id;
  const dot     = p.dot;
  const memo    = "윈터타이어&이월상품취소불가 익일출고 (당일출고 문의 필수)";

  const js = `
(async function(){
  function sleep(ms){ return new Promise(r=>setTimeout(r,ms)); }
  window.__tireping_done = false;

  // STEP1: 제조사
  var sc = $('#company')[0]&&$('#company')[0].selectize;
  if(!sc){ console.error('❌ selectize 없음'); return; }
  var compVal=null;
  for(var k in sc.options){
    if(sc.options[k].text&&sc.options[k].text.trim()==='${mfr}'){compVal=String(sc.options[k].value);break;}
  }
  if(!compVal){ console.error('❌ 제조사 못찾음: ${mfr}'); return; }
  sc.setValue(compVal);
  console.log('✅ 제조사:', '${mfr}', compVal);

  // STEP2: 품명 AJAX
  var patVal=null;
  await new Promise(function(resolve){
    $.post('/ajax/tire/pattern/'+compVal,function(data){
      if(!data||!data.length){ console.error('❌ 품명 없음'); resolve(); return; }
      var str='<option value="">제품명</option>';
      for(var i=0;i<data.length;i++){
        var m=data[i].name&&data[i].name.trim().indexOf('${product}')!==-1;
        if(m&&!patVal) patVal=String(data[i].id);
        str+='<option value="'+data[i].id+'"'+(m?' selected':'')+'>'+data[i].name+'</option>';
      }
      try{$('#pattern')[0].selectize.destroy();}catch(e){}
      $('#pattern').html(str);
      console.log('✅ 품명 로드:', data.length+'개');
      resolve();
    }).fail(function(){ console.error('❌ 품명 AJAX 실패'); resolve(); });
  });
  if(!patVal){ console.error('❌ 품명 못찾음: ${product}'); return; }
  console.log('✅ 품명:', '${product}', patVal);

  // STEP3: 사이즈 AJAX + _tire 직접 세팅
  await new Promise(function(resolve){
    $.post('/ajax/tire/ajaxpage/'+patVal,function(data){
      if(!data||!data.length){ console.error('❌ 사이즈 없음'); resolve(); return; }
      _pattern=data; drawTire();
      console.log('✅ 사이즈 목록:', data.length+'개');
      resolve();
    }).fail(function(){ console.error('❌ 사이즈 AJAX 실패'); resolve(); });
  });

  await new Promise(function(resolve){
    $.post('/ajax/tire/price/${tire_id}',function(data){
      if(!data){ console.error('❌ tire/price 실패'); resolve(); return; }
      _tire=parseInt('${tire_id}');
      _price=data.factoryprice||0;
      _directprice=data.factoryprice||0;
      if(typeof comma==='function')
        document.getElementById('divFactoryprice').innerHTML=comma(data.factoryprice);
      if(data.width&&data.height&&data.inch)
        document.getElementById('txtTire').value=data.width+' '+data.height+' '+data.inch;
      var li=document.getElementById('divTr${tire_id}');
      if(li) li.style.background='#edf4ff';
      console.log('✅ 사이즈 선택 _tire='+_tire+' 공장도가='+data.factoryprice);
      resolve();
    }).fail(function(){ console.error('❌ tire/price AJAX 실패'); resolve(); });
  });
  if(!_tire||_tire===0){ console.error('❌ _tire 세팅 실패'); return; }
  await sleep(200);

  // STEP4: 나머지 입력
  var priceEl=document.querySelector('input#price');
  if(priceEl){
    priceEl.value='${sellPrice}';
    if(typeof changePrice==='function') changePrice(1);
    else priceEl.dispatchEvent(new KeyboardEvent('keyup',{bubbles:true}));
    console.log('✅ 판매가:', ${sellPrice});
  }
  var dotEl=document.querySelector('select#dot');
  if(dotEl){ dotEl.value='${dot}'; dotEl.dispatchEvent(new Event('change',{bubbles:true})); }
  var cntEl=document.querySelector('input#count');
  if(cntEl){ cntEl.value='${stock}'; cntEl.dispatchEvent(new Event('input',{bubbles:true})); }
  var memoEl=document.querySelector('input#memo');
  if(memoEl) memoEl.value='${memo}';
  var hourEl=document.querySelector('select#send_hour');
  var minEl=document.querySelector('select#send_min');
  if(hourEl){ hourEl.value='15'; hourEl.dispatchEvent(new Event('change',{bubbles:true})); }
  if(minEl){  minEl.value='00';  minEl.dispatchEvent(new Event('change',{bubbles:true})); }
  var kindEl=document.querySelector('input[name="send_kind"][value="0"]');
  if(kindEl&&!kindEl.checked){ kindEl.checked=true; kindEl.dispatchEvent(new Event('change',{bubbles:true})); }

  window.__tireping_done = true;
  console.log('%c✅ 자동입력 완료!','color:green;font-size:14px;font-weight:bold');
})();
`.trim();
  return { js, sellPrice };
}

async function openInsertPage(p, autoSubmit) {
  const stock = parseInt($("inp-stock").value) || 8;
  const maxDcRaw = $("inp-maxdc").value.trim();
  const maxDc = maxDcRaw ? parseFloat(maxDcRaw) : null;
  const { js, sellPrice } = buildInsertJS(p, maxDc, stock);
  const session = crypto.randomUUID();

  // storage 에 커맨드 저장 → content.js 가 페이지 로드 시 감지
  await new Promise(r => chrome.storage.local.set({
    tireping_pending: { session, js, auto_submit: autoSubmit }
  }, r));

  // 등록 페이지 열기
  chrome.tabs.create({ url: `${BASE}/sell/price/insert`, active: true });
  st(`🌐 ${p.product} ${p.size} 판매가:${comma(sellPrice)}원 | ${autoSubmit ? "자동등록 중..." : "입력 후 저장하기 클릭"}`);

  // 완료 대기
  return new Promise(resolve => {
    const check = setInterval(() => {
      chrome.storage.local.get("tireping_done", r => {
        const done = r.tireping_done;
        if (done && done.session === session) {
          clearInterval(check);
          chrome.storage.local.remove("tireping_done");
          resolve(done.ok);
        }
      });
    }, 500);
    setTimeout(() => { clearInterval(check); resolve(false); }, 30000);
  });
}

async function bulkUpload() {
  const targets = [...checkedSet].map(i => shownProducts[i]).filter(p => p && !p.is_mine);
  if (!targets.length) { alert("체크된 미판매 상품이 없습니다"); return; }

  const stock = parseInt($("inp-stock").value) || 8;
  const maxDcRaw = $("inp-maxdc").value.trim();
  const maxDc = maxDcRaw ? parseFloat(maxDcRaw) : null;
  const dcMsg = maxDc !== null ? `\n제한DC율: ${maxDc}%` : "";

  if (!confirm(`미판매 상품 ${targets.length}개를 자동 등록합니다.${dcMsg}\n계속할까요?`)) return;

  loading(true, `0/${targets.length} 업로드 중...`);
  let success = 0;
  for (let k = 0; k < targets.length; k++) {
    const p = targets[k];
    $("loading-msg").textContent = `[${k+1}/${targets.length}] ${p.product} ${p.size}`;
    const ok = await openInsertPage(p, true);  // auto_submit=true
    if (ok) success++;
    await sleep(500);
  }
  loading(false);
  st(`✅ ${success}/${targets.length}개 업로드 완료`);
}

// ── 이벤트 바인딩 ─────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", async () => {
  // 초기화
  st("로그인 확인 중...");
  const loggedIn = await checkLogin();
  if (loggedIn) {
    st("제조사 목록 로드 중...");
    await loadCompanies();
    const cache = await loadCache();
    st(`✅ 준비 완료 — 캐시 ${Object.keys(cache).length}개`);
  }

  // 제조사 변경 → 제품명 로드
  $("sel-mfr").addEventListener("change", () => loadPatterns($("sel-mfr").value));

  // 검색
  $("btn-search").addEventListener("click", () => doSearch(true));
  $("btn-fresh").addEventListener("click",  () => doSearch(false));
  $("btn-reset").addEventListener("click",  () => {
    $("inp-size").value = ""; $("sel-mfr").value = ""; $("sel-prod").value = "";
    $("sel-dot").value  = ""; $("sel-order").value = "";
    allProducts = []; shownProducts = []; filterState = {}; checkedSet.clear();
    $("tbody").innerHTML = ""; $("thead").innerHTML = "";
    $("summary-text").textContent = "초기화 완료";
    updateFilterLabel();
  });
  document.addEventListener("keydown", e => { if (e.key === "Enter") doSearch(true); });

  // 액션 버튼
  $("btn-check-all").addEventListener("click",   checkAll);
  $("btn-uncheck-all").addEventListener("click", uncheckAll);
  $("btn-check-notlow").addEventListener("click", checkNotLow);
  $("btn-check-notmine").addEventListener("click", checkNotMine);
  $("btn-bulk-low").addEventListener("click",    bulkLow);
  $("btn-bulk-raise").addEventListener("click",  bulkRaise);
  $("btn-refresh-now").addEventListener("click", refreshLowest);
  $("btn-bulk-upload").addEventListener("click", bulkUpload);
  $("btn-auto").addEventListener("click",        toggleAuto);
  $("btn-clear-filter").addEventListener("click", () => { filterState = {}; applyFilters(); });

  // 자동갱신 알람 수신
  chrome.runtime.onMessage.addListener(msg => {
    if (msg.type === "ALARM_REFRESH" && autoRefreshing) refreshLowest();
  });

  // ⧉ 팝업창으로 분리
  $("btn-popout")?.addEventListener("click", () => {
    // 현재 사이드패널 URL을 독립 팝업창으로 열기
    chrome.windows.create({
      url: chrome.runtime.getURL("sidebar.html"),
      type: "popup",
      width: 1400,
      height: 860,
      focused: true,
    });
  });

  // 테이블 이벤트 위임
  $("tbody").addEventListener("click", e => {
    const td = e.target.closest("td");
    const tr = e.target.closest("tr");
    if (!tr) return;
    const idx = parseInt(tr.dataset.idx);
    if (isNaN(idx) || idx >= shownProducts.length) return;
    const p = shownProducts[idx];

    // 체크박스
    if (td?.classList.contains("chk-cell")) {
      if (e.shiftKey && lastShiftIdx !== null) {
        const [a, b] = [Math.min(idx, lastShiftIdx), Math.max(idx, lastShiftIdx)];
        const state  = checkedSet.has(lastShiftIdx);
        for (let i = a; i <= b; i++) state ? checkedSet.add(i) : checkedSet.delete(i);
        rerenderChecks();
      } else {
        toggleCheck(idx);
      }
      return;
    }

    // 최저가↓
    if (e.target.classList.contains("btn-low")) {
      changePrice(p, idx, p.lowest_price - 10); return;
    }
    // 2등↑
    if (e.target.classList.contains("btn-raise")) {
      changePrice(p, idx, p.second_price - 10); return;
    }
    // 📤등록 (단일, auto_submit=false → 입력만)
    if (e.target.classList.contains("btn-upload")) {
      openInsertPage(p, false); return;
    }
  });

  // 더블클릭 → 미판매 등록 (auto_submit=false)
  $("tbody").addEventListener("dblclick", e => {
    const tr = e.target.closest("tr");
    if (!tr) return;
    const idx = parseInt(tr.dataset.idx);
    if (isNaN(idx)) return;
    const p = shownProducts[idx];
    if (p && !p.is_mine) openInsertPage(p, false);
  });

  // 헤더 이벤트는 renderTable 안에서 직접 바인딩됨

  // 액션바 우클릭 → 컬럼 필터 선택 팝업
  $("action-bar").addEventListener("contextmenu", e => {
    e.preventDefault();
    showColumnFilterPicker(e.clientX, e.clientY);
  });
});
