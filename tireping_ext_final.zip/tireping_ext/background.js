// background.js - 타이어핑 봇 service worker

// ── 사이드패널 열기 ──────────────────────────────────────────
chrome.action.onClicked.addListener(tab => {
  chrome.sidePanel.open({ windowId: tab.windowId });
});

// ── 메시지 핸들러 ────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  // fetch 대리 실행 (sidebar → background → tireping)
  if (msg.type === "FETCH") {
    fetch(msg.url, msg.options || {})
      .then(async r => {
        const text = await r.text();
        sendResponse({ ok: r.ok, status: r.status, text });
      })
      .catch(e => sendResponse({ ok: false, error: String(e) }));
    return true;
  }

  // 페이지에 JS 실행 (MAIN 컨텍스트, CSP 우회)
  if (msg.type === "EXEC_JS" && sender.tab) {
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id },
      world: "MAIN",
      func: (code) => { eval(code); },
      args: [msg.js],
    }).then(() => sendResponse({ ok: true }))
      .catch(e => sendResponse({ ok: false, error: String(e) }));
    return true;
  }

  // 저장하기 버튼 클릭
  if (msg.type === "CLICK_SAVE" && sender.tab) {
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id },
      world: "MAIN",
      func: () => {
        const btn = document.querySelector('button[type="submit"]');
        if (btn) { btn.click(); return true; }
        for (const b of document.querySelectorAll("button")) {
          if (b.textContent.includes("저장하기")) { b.click(); return true; }
        }
        return false;
      },
    }).then(r => sendResponse({ ok: r?.[0]?.result ?? false }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }

  // 완료 플래그 set/get
  if (msg.type === "SET_FLAG" && sender.tab) {
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id },
      world: "MAIN",
      func: (v) => { window.__tireping_done = v; },
      args: [msg.value],
    }).then(() => sendResponse({ ok: true }))
      .catch(() => sendResponse({ ok: false }));
    return true;
  }
  if (msg.type === "GET_FLAG" && sender.tab) {
    chrome.scripting.executeScript({
      target: { tabId: sender.tab.id },
      world: "MAIN",
      func: () => window.__tireping_done === true,
    }).then(r => sendResponse({ value: r?.[0]?.result ?? false }))
      .catch(() => sendResponse({ value: false }));
    return true;
  }

  // 자동갱신 알람 설정
  if (msg.type === "SET_ALARM") {
    chrome.alarms.clear("autoRefresh", () => {
      if (msg.minutes > 0) {
        chrome.alarms.create("autoRefresh", { periodInMinutes: msg.minutes });
      }
      sendResponse({ ok: true });
    });
    return true;
  }
  if (msg.type === "CLEAR_ALARM") {
    chrome.alarms.clear("autoRefresh");
    sendResponse({ ok: true });
    return true;
  }
});

// 알람 → sidebar 에 갱신 요청
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === "autoRefresh") {
    chrome.runtime.sendMessage({ type: "ALARM_REFRESH" }).catch(() => {});
  }
});
