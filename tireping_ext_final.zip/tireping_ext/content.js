// content.js - /sell/price/insert 페이지 자동입력
// sidebar.js 가 chrome.storage.local 에 pending 커맨드를 저장
// → content script 가 감지해서 실행

const STORAGE_KEY = "tireping_pending";

async function main() {
  await sleep(1500); // selectize 초기화 대기

  // storage 에서 커맨드 읽기
  const store = await chromeGet(STORAGE_KEY);
  const cmd = store[STORAGE_KEY];
  if (!cmd || !cmd.js || !cmd.session) {
    console.log("[타이어핑봇] 커맨드 없음");
    return;
  }

  const { session, js, auto_submit } = cmd;
  console.log(`[타이어핑봇] 커맨드 수신 session=${session} auto_submit=${auto_submit}`);

  // 완료 플래그 초기화
  window.__tireping_done = false;

  // JS 실행 (background → MAIN 컨텍스트 eval, CSP 우회)
  await bgMessage({ type: "EXEC_JS", js });

  // 완료 플래그 대기 (최대 20초)
  const done = await waitFor(() => window.__tireping_done === true, 20000, 300);
  console.log("[타이어핑봇] JS 완료:", done ? "✅" : "⚠️ 타임아웃");

  await sleep(300);

  // auto_submit: 저장하기 클릭
  if (auto_submit) {
    const saved = await bgMessage({ type: "CLICK_SAVE" });
    console.log("[타이어핑봇] 저장하기:", saved?.ok ? "✅" : "❌");
    await sleep(2500);
  }

  // 완료 → storage 에 결과 저장 (sidebar 가 polling 으로 감지)
  await chromeSet({ tireping_done: { session, ok: true } });
  // pending 삭제
  await chromeRemove(STORAGE_KEY);

  console.log("[타이어핑봇] 완료");
}

function bgMessage(msg) {
  return new Promise(resolve => chrome.runtime.sendMessage(msg, resolve));
}

function chromeGet(key) {
  return new Promise(resolve => chrome.storage.local.get(key, resolve));
}

function chromeSet(obj) {
  return new Promise(resolve => chrome.storage.local.set(obj, resolve));
}

function chromeRemove(key) {
  return new Promise(resolve => chrome.storage.local.remove(key, resolve));
}

async function waitFor(condFn, maxMs, intervalMs) {
  let elapsed = 0;
  while (elapsed < maxMs) {
    if (condFn()) return true;
    await sleep(intervalMs);
    elapsed += intervalMs;
  }
  return false;
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

main();
